/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pbo;

/**
 *
 * @author USER90
 */
public class Pbo {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
